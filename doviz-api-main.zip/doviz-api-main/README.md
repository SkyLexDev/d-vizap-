# Döviz API Template

### Çıktı
```json
{
"USD": {
 "alis": "15.9249",
 "satis": "15.9536"
 },
"EUR": {
 "alis": "16.8483",
 "satis": "16.8786"
 }, 
"GBP": {
 "alis": "19.8372", 
 "satis": "19.9406"
 }
}
```
